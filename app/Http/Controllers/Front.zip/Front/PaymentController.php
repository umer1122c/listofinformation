<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\User;
use App\Models\Product;
use App\Models\UserLoginData;
use App\Classes\CommonLibrary;
use commonHelper;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Copoun;
use App\Models\CouponUser;
use App\Models\Setting;
use App\Http\Controllers\Controller;
use Paystack;
use Session;
use Validator;
use Gloudemans\Shoppingcart\Facades\Cart;
use DB;
use Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    
     public function __construct()
    {
        /** Paystack api context **/
        $settings = Setting::where('settings_id' , 1)->first();
        //dd($account);
        if($settings){
            if($settings->payment_mod == 1){
                config(['paystack.publicKey' => $settings->PAYSTACK_PUBLIC_KEY_LIVE]);
                config(['paystack.secretKey' => $settings->PAYSTACK_SECRET_KEY_LIVE]);
            }else{
                config(['paystack.publicKey' => $settings->PAYSTACK_PUBLIC_KEY_LOCAL]);
                config(['paystack.secretKey' => $settings->PAYSTACK_SECRET_KEY_LOCAL]);
            }
        }
        
    }

    /**
     * Redirect the User to Paystack Payment Page
     * @return Url
     */
    public function payment(Request $request)
    {
        try{
            $jsonrequest = $request->all();
            //dd($jsonrequest['reference']);
            $user = $request->user();
            $productsArray = CartItem::where('user_id' , session('user_id'))->get();
            $deviceType = 'web';
            $order_id = substr(str_shuffle('123456789123456789123456789321654987'),0,6);
            if(count($productsArray) > 0){
                $transArray = [];
                $transArray['order_id'] = $order_id;
                $transArray['order_type'] = 1;
                $transArray['deviceType'] = $deviceType;
                $transArray['user_id'] = session('user_id');
                $transArray['type'] = $jsonrequest['payment_method'];
                $transArray['status'] = 'Pending';
                $transArray['reference'] = $jsonrequest['reference'];
                $transArray['order_total'] = $jsonrequest['sub_total'];
                $transArray['discount_amount'] = $jsonrequest['discount_amount'];
                $transArray['coupon_code'] = $jsonrequest['coupon_code'];
                $transArray['wallet_amount'] = $jsonrequest['wallet_amount'];
                $transArray['address'] = $jsonrequest['address_id'];
                $transArray['contact_type'] = 'Call';
                $transArray['shipping_cost'] = $jsonrequest['shipping_cost'];
                $transArray['delivery_type'] = $jsonrequest['delivery_type'];
                $transArray['dilivery_date'] = $jsonrequest['delivery_date'];
                $transArray['created_at'] = date('Y-m-d H:i:s');
                $transArray['updated_at'] = date('Y-m-d H:i:s');
                Order::insert($transArray);
                foreach($productsArray as $row){
                    //dd($row);
                    $itemsArray = [];
                    $itemsArray['order_id'] = $order_id;
                    $itemsArray['product_id'] = $row['product_id'];
                    $itemsArray['prod_title'] = $row['name'];
                    $itemsArray['quantity'] = $row['qty'];
                    $itemsArray['price'] = $row['price'];
                    $itemsArray['pally_id'] = $row['pally_id'];
                    $itemsArray['type'] = $row['type'];
                    $itemsArray['attribute_id'] = $row['attribute_id'];
                    $itemsArray['attribute_cost'] = $row['attribute_cost'];
                    $itemsArray['attribute_name'] = $row['attribute_name'];
                    DB::table('order_details')->insert($itemsArray);
                }
                if($jsonrequest['wallet_amount'] > 0){
                    $savTrans = DB::table('transactions')->insert(['from_user_id' => 0 ,'to_user_id' => session('user_id') ,'amount'=> $jsonrequest['wallet_amount'],'trans_type'=> 1,'status'=> 0, 'created_at' => date('Y-m-d h:i:s'), 'updated_at' => date('Y-m-d h:i:s')]);
                }
                $totalAmount = $jsonrequest['sub_total'] + $jsonrequest['shipping_cost'] - $jsonrequest['discount_amount'];
                if($jsonrequest['payment_method'] == 'direct'){
                    $reference = Str::random(25);
                    Order::where('order_id' , $order_id)->update(['reference' => $reference]);
                    CartItem::where('user_id' , session('user_id'))->delete();
                    $nororders = DB::table('orders')->where('order_id' , $order_id)->first();
                    $nor_order_id = $nororders->order_id;
                    $dilivery_date = $nororders->dilivery_date;
                    $shipping_cost = $nororders->shipping_cost;
                    $wallet_amount = $nororders->wallet_amount;
                    if($nororders->discount_amount == null || $nororders->discount_amount == ''){
                        $discount_amount = 0.00;
                    }else{
                        $discount_amount = $nororders->discount_amount;
                    }
                    
                    $address = DB::table('user_address')
                                    ->select('user_address.*','areas.*')
                                    ->join('areas', 'areas.id', '=', 'user_address.area_id' , 'left')
                                    ->where('address_id' , $nororders->address)
                                    ->first();
                    if($address){
                        $delivery_address1 = $address->house_name.' '.$address->street;
                        $delivery_address2 = $address->town.' '.$address->name;
                    }else{
                        $delivery_address1 = "";
                        $delivery_address2 = "";
                    }
                    $order_details = DB::table('order_details')->where('order_id' , $nor_order_id)->get();
                    $user_id = $nororders->user_id;
                    $users = User::where('user_id' , $user_id)->first();
                    $link = $order_details;
                    //dd($link);
                    //echo '<pre>'; print_r($link);exit;
                    $email_subject = 'Order Detail';
                    $user_name = $users->first_name;
                    $email_from = 'hello@pricepally.com';
                    $this->order_send_email($users->email, $user_name, $email_subject, $email_from,$nor_order_id,$dilivery_date,$shipping_cost,$discount_amount,$wallet_amount,$delivery_address1,$delivery_address2, $link,'order_email');
                    //return redirect('order/detail/'.$order_id);
                    Session::flash('success_msg', 'Order place successfully.'); 
                    return redirect('payment/success?order_id='.$nor_order_id);
                }elseif($jsonrequest['payment_method'] == 'paystack'){
                    return Paystack::getAuthorizationUrl()->redirectNow();
                }
            }else{
                return redirect('my/cart');
            }
        }catch(\Exception $e){
            return redirect('my/cart');
        }
        
        
    }
    
    /**
     * Obtain Paystack payment information
     * @return void
     */
    public function handleGatewayCallback()
    {
        //Log::useFiles(storage_path().'/logs/myPaymentsLogs.log');
        //echo 'test print';exit;
        $data['title'] = 'Payment Success';
        $data['class'] = 'success';
        try{
            $user_id = Session::get('user_id');
            $paymentDetails = Paystack::getPaymentData();
            //dd($paymentDetails);
            $reference = $paymentDetails['data']['reference'];
            $paystck_id = $paymentDetails['data']['id'];
            //Log::info(response()->json(['status'=>1,"message"=>'Get responce from paystack.','paystck_responce' => $paymentDetails,'reference' => $reference],200));
            if(isset($paymentDetails['status']) && $paymentDetails['status'] == 1){
                $orders = DB::table('orders')->where('reference' , $reference)->first();
                if($orders){
                    $order_id = $orders->order_id;
                    $user_id = $orders->user_id;
                }
                $order_details = DB::table('order_details')->where('order_id' , $order_id)->get();
                if(count($order_details) > 0){
                    foreach($order_details as $row){
                        $pally_id = $row->pally_id;
                        $open_pallys = DB::table('open_pallys')->where('pally_id' , $pally_id)->first();
                        if($open_pallys){
                            $open_pallys->pally_type;
                            $number_of_person = $open_pallys->number_of_person;
                            $pally_count = $open_pallys->pally_count;
                            $users_name = User::where('user_id' , $user_id)->first();
                            if($users_name){
                                $users_name = $users_name->first_name;
                            }else{
                                $users_name = '';
                            }
                            if($open_pallys->pally_type == 'Open'){
                                $pally_users = DB::table('close_pally_users')->where('pally_id' , $pally_id)->get();
                                if(count($pally_users) > 0){
                                    foreach($pally_users as $row1){
                                        if($user_id != $row1->user_id){
                                            $usersname = User::where('user_id' , $row1->user_id)->first();
                                            $title = 'Open Pally Paid';
                                            $body = $users_name.' has paid a share of the open pally';
                                            $username = $usersname;
                                            $pally_id = $pally_id;
                                            $type = 'pally_friend';
                                            //Send Notification
                                            $this->sendNotificationToUser($user_id,$row1->user_id,$usersname,$title,$body,$pally_id,$type);
                                            //End Notification
                                        }
                                    }
                                }
                                if($pally_count <= $number_of_person){
                                    $pallyCurrentUserArray = [];
                                    $pallyCurrentUserArray['type'] = 'Open';
                                    $pallyCurrentUserArray['pally_id'] = $pally_id;
                                    $pallyCurrentUserArray['user_id'] = $user_id;
                                    $pallyCurrentUserArray['status'] = 1;
                                    $pallyCurrentUserArray['created_at'] = time();
                                    $pallyCurrentUserArray['updated_at'] = time();
                                    DB::table('close_pally_users')->insert($pallyCurrentUserArray);
                                    $close_pally_users = DB::table('close_pally_users')->where('user_id' , $user_id)->where('pally_id' , $pally_id)->first();
                                    if($close_pally_users){
                                        DB::table('close_pally_users')->where('id' , $close_pally_users->id)->update(['status' => 1]);
                                    }
                                    $order_details_res = DB::table('order_details')->where('order_id' , $row->order_id)->where('pally_id' , $pally_id)->first();
                                    DB::table('close_pally_users')->where('user_id' , $user_id)->where('pally_id' , $pally_id)->update(['status' => 1]);
                                    $pally_count_increment = $pally_count + $order_details_res->quantity;
                                    if($number_of_person == $pally_count_increment){
                                        DB::table('open_pallys')->where('pally_id' , $pally_id)->update(['pally_count' => $pally_count_increment,'status' => 1]);
                                    }else{
                                        DB::table('open_pallys')->where('pally_id' , $pally_id)->update(['pally_count' => $pally_count_increment,'status' => 0]);
                                    }
                                }
                            }else{
                                //return '2222';
                                if($pally_count == 0){
                                    $pally_users = DB::table('close_pally_users')->where('pally_id' , $pally_id)->get();
                                    //dd($pally_users);
                                    if(count($pally_users) > 0){
                                        foreach($pally_users as $row){
                                            if($user_id != $row->user_id){
                                                $usersname = User::where('user_id' , $row->user_id)->first();
                                                $title = 'New Pally Request';
                                                $body = $users_name.' is inviting you to share a bulk purchase via a close pally';
                                                $username = $usersname;
                                                $pally_id = $pally_id;
                                                $type = 'close';
                                                //Send Notification
                                                $this->sendNotificationToUser($user_id,$row->user_id,$usersname,$title,$body,$pally_id,$type);
                                                //End Notification
                                            }
                                        }
                                    } 
                                    
                                    
                                }
                                $pally_users = DB::table('close_pally_users')->where('pally_id' , $pally_id)->get();
                                //dd($pally_users);
                                if(count($pally_users) > 0){
                                    foreach($pally_users as $row){
                                        if($user_id != $row->user_id){
                                            $usersname = User::where('user_id' , $row->user_id)->first();
                                            $title = 'Close Pally Paid';
                                            $body = $users_name.' has paid a share of the close pally';
                                            $username = $usersname;
                                            $pally_id = $pally_id;
                                            $type = 'pally_friend';
                                            //Send Notification
                                            $this->sendNotificationToUser($user_id,$row->user_id,$usersname,$title,$body,$pally_id,$type);
                                            //End Notification
                                        }
                                    }
                                }
                                if($pally_count <= $number_of_person){
                                    DB::table('close_pally_users')->where('user_id' , $user_id)->where('pally_id' , $pally_id)->update(['status' => 1]);
                                    $pally_count_increment = $pally_count + 1;
                                    if($number_of_person == $pally_count_increment){
                                        DB::table('open_pallys')->where('pally_id' , $pally_id)->update(['pally_count' => $pally_count_increment,'status' => 1]);
                                    }else{
                                        $pally_count_increment = $pally_count + 1;
                                        DB::table('open_pallys')->where('pally_id' , $pally_id)->update(['pally_count' => $pally_count_increment,'status' => 0]);
                                    }
                                }
                            }
                        }
                    }
                }
                DB::table('orders')->where('reference' , $reference)->update(['status' => 'In Progress' ,'paystck_id' => $paystck_id , 'paystck_responce' => json_encode($paymentDetails)]);
                
                //Send Order Email
                $nororders = DB::table('orders')->where('reference' , $reference)->first();
                if($nororders){
                    $nor_order_id = $nororders->order_id;
                    $dilivery_date = $nororders->dilivery_date;
                    $shipping_cost = $nororders->shipping_cost;
                    $wallet_amount = $nororders->wallet_amount;
                    if($nororders->discount_amount == null || $nororders->discount_amount == ''){
                        $discount_amount = 0.00;
                    }else{
                        $discount_amount = $nororders->discount_amount;
                    }
                    
                    $address = DB::table('user_address')
                                    ->select('user_address.*','areas.*')
                                    ->join('areas', 'areas.id', '=', 'user_address.area_id' , 'left')
                                    ->where('address_id' , $nororders->address)
                                    ->first();
                    if($address){
                        $delivery_address1 = $address->house_name.' '.$address->street;
                        $delivery_address2 = $address->town.' '.$address->name;
                    }else{
                        $delivery_address1 = "";
                        $delivery_address2 = "";
                    }
                    $order_details = DB::table('order_details')->where('order_id' , $nor_order_id)->get();
                    $user_id = $nororders->user_id;
                    $users = User::where('user_id' , $user_id)->first();
                    $link = $order_details;
                    //dd($link);
                    //echo '<pre>'; print_r($link);exit;
                    $email_subject = 'Order Detail';
                    $user_name = $users->first_name;
                    $email_from = 'hello@pricepally.com';
                    $this->order_send_email($users->email, $user_name, $email_subject, $email_from,$nor_order_id,$dilivery_date,$shipping_cost,$discount_amount,$wallet_amount,$delivery_address1,$delivery_address2, $link,'order_email');
                }
                //Send Order Email
                
                //Log::info(response()->json(['status'=>1,"message"=>'Order place successfully.','paystck_responce' => $paymentDetails,'reference' => $reference],200));
                $cartItem = CartItem::where('user_id' , $user_id)->delete();
                $ord_code = DB::table('orders')->where('reference' , $reference)->first();
                if($ord_code->coupon_code != ''){
                    $couponUser = new CouponUser();
                    $couponUser->user_id = $ord_code->user_id;
                    $couponUser->coupon_code = $ord_code->coupon_code;
                    $couponUser->save();
                }
                //return $orders->user_id;
                $userOrders = DB::table('orders')->where('status' , 'In Progress')->where('user_id' , $orders->user_id)->count();
                //dd($userOrders);
                if($userOrders == 1){
                    $to_user_id = $user_id;
                    $currentUserTransaction = DB::table('transactions')->where('to_user_id' , $to_user_id)->first();
                    if($currentUserTransaction){
                        $from_user_id = $currentUserTransaction->from_user_id;
                        DB::table('transactions')->where('from_user_id' , $from_user_id)->where('to_user_id' , $to_user_id)->update(['status' => 1]);
                        DB::table('transactions')->where('from_user_id' , $to_user_id)->where('to_user_id' , $from_user_id)->update(['status' => 1]);
                    }
                }
                Session::flash('success_msg', 'Order place successfully.'); 
                return redirect('payment/success?order_id='.$nor_order_id);
            }else{
                //DB::table('orders')->where('reference' , $reference)->update(['paystck_id' => $paystck_id , 'paystck_responce' => json_encode($paymentDetails)]);
                Log::info(response()->json(['status'=>0,"message"=>'Payment failed.','paystck_responce' => $paymentDetails,'reference' => $reference],200));
                return redirect('payment/failed');
            }
        }catch(\Exception $e){
            //DB::table('orders')->where('reference' , $reference)->update(['paystck_id' => $paystck_id , 'paystck_responce' => json_encode($paymentDetails)]);
            //Log::info(response()->json(['status'=>0,"message"=>$e->getMessage(),'paystck_responce' => $paymentDetails,'reference' => $reference],200));
            return redirect('payment/failed');
        }
    }
    
    public function sendNotificationToUser($user_id , $follower_id,$username,$title,$body,$pally_id,$type){
        $users = UserLoginData::select('deviceToken','userId')->where('userId' , $follower_id)->where('tokenStatus',0)->get();
        if(count($users) > 0){
            $deviceToken = [];
            foreach($users as $key => $val ){
                $deviceToken[] = $val->deviceToken;
            }
            $message =  array(
                            'type' => 'notification',
                            'title' => $title,
                            'body' => $body,
                            'username' => $username,
                            'pally_id' => $pally_id,
                            'notification_userid' => $follower_id,
                            'type1' => $type,
                            'sound'=> 'default',
                            'content-available'=> true,
                            'icon' => 'chat1'
                        );
            commonHelper::firebase($deviceToken,$message);
            commonHelper::saveNotification($user_id,$follower_id,$username,$title,$body,$type,$pally_id);
        }
    }
    
    public function order_send_email($email, $user_name, $email_subject, $email_from,$order_id,$dilivery_date,$shipping_cost,$discount_amount,$wallet_amount, $delivery_address1,$delivery_address2,$link,$view_name) {
        $res['userName'] = $user_name;
        $res['orders'] = $link;
        $res['shipping_cost'] = $shipping_cost;
        $res['delivery_address1'] = $delivery_address1;
        $res['delivery_address2'] = $delivery_address2;
        $res['order_id'] = $order_id;
        $res['discount_amount'] = $discount_amount;
        $res['wallet_amount'] = $wallet_amount;
        $res['dilivery_date'] = $dilivery_date;
        $res['url'] = url('/');
        //echo '<pre>'; print_r($res['orders']);exit;
        Mail::send('email/'.$view_name , $res, function ($message) use ($email_from, $email, $user_name, $email_subject) {
            $message->from($email_from, $name = 'Pricepally');
            $message->to($email, $user_name)->subject($email_subject);
            $message->to('rizwan@decodershub.com', $user_name)->subject($email_subject);
        });
    }
    
    public function successPayment(Request $request)
    {
        $data['title'] = 'Payment Success';
        $data['class'] = 'success';
        $data['order_id'] = $request->order_id;
        $Order = Order::where('order_id' , $request->order_id)->first();
        if($Order){
            $data['total'] = $Order->order_total + $Order->shipping_cost - $Order->discount_amount - $Order->wallet_amount;
        }else{
            $data['total'] = 0;
        }
        return view('front/home/thankyou' , $data);
    }
    
    public function failerPayment()
    {
        $data['title'] = 'Payment Failed';
        $data['class'] = 'failed';
        return view('front/home/failed_payment' , $data);
    }
}