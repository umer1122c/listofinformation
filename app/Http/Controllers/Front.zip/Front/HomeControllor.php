<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\Attribute;
use App\Models\UserLoginData;
use App\Models\ServiceCategory;
use App\Models\Slider;
use App\Models\User;
use App\Models\Award;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
use Illuminate\Support\Facades\Log;

class HomeControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    public function uploadCSV(Request $request){
        $data['title'] = 'Upload CSV';
        $data['class'] = 'csv';
        $data['table'] = 'Upload CSV';
        
        set_time_limit(1000);

        $file = URL::to('/').'/PRICEPALLYCOST.csv';
        $handle = fopen($file, "r");
        $header = false;
        $csvLine = fgetcsv($handle);
        
        while ($csvLine = fgetcsv($handle, 1000, ",")) {
            if ($header) {
                $header = true;
            } else {
                //dd($csvLine);
                $areas = DB::table('areas')->where('name' , $csvLine[1])->first();
                if($areas){
                    DB::table('areas')->where('name' , $csvLine[1])->update([
                        'name' => $csvLine[1],
                        'value1' => $csvLine[2],
                        'value2' => $csvLine[3],
                        'value2' => $csvLine[4]
                    ]);
                }else{
                    DB::table('areas')->insert([
                        'name' => $csvLine[1],
                        'value1' => $csvLine[2],
                        'value2' => $csvLine[3],
                        'value2' => $csvLine[4]
                    ]);
                }

            }
        }
          return 'Added Successfully';  
    } 
    
    public function checkNotification()
    {
        //return date('h:i');
        //return storage_path();
        //Log::useFiles(storage_path().'/logs/mycustom.log');
        Log::channel('customlog')->info('Hello world!!');
        $open_pallys = DB::table('open_pallys')->whereDate('pally_date', '=', date('Y-m-d'))->get();
        dd($open_pallys);
        $currentTime = strtotime(date('h:i'));
        $startTime = strtotime('08:00');
        $endTime = strtotime('09:00');
        if($currentTime >= $startTime && $currentTime <= $endTime){
            if(count($open_pallys) > 0){
                
                $users = User::get();
                if(count($users) > 0){
                    foreach($users as $row){
                        $users = UserLoginData::select('deviceToken','userId')->where('userId' , $row->user_id)->where('tokenStatus',0)->get();
                        $device_token = '';
                        if($users){
                            foreach($users as $user){
                                $device_token = $user->deviceToken;
                                //$device_token = 'eycoPZxyPcc:APA91bGN7UAoVxGL3jBm1YdfFABWGVqnWwsU_ZWS0FmImjlI8OJ2vZD-reXVLDv0lkch3X_0n3f6gO_DzXBjO9i5rOiiDcDlSW6asb1Co3VOoHuQK28rvSgGlrUfW5vrubH_FHzBBhs0';
                                $message =  array(
                                                'type' => 'notification',
                                                'title' => 'Pally notification',
                                                'body' => 'Hello '.$row->first_name.', check out '.count($open_pallys).' open pallys for discounted food items available, join a pally now!',
                                                'username' => $row->first_name,
                                                'pally_id' => 0,
                                                'type1' => 'open',
                                                'sound'=> 'default',
                                                'content-available'=> true,
                                                'icon' => 'chat1'
                                            );
                                $res = $this->firebase($device_token,$message);
                                Log::info(response()->json(['status'=>1,"message"=>'Hello '.$row->first_name.', check out '.count($open_pallys).' open pallys for discounted food items available, join a pally now!','data' => $res],200));
                            }
                        }
                    }
                }
            }
        }
    }
    
    public function home()
    {
        $data['title'] = 'Home';
        $data['description'] = 'Home';
        $data['class'] = 'home';
        $data['prodImageUrl'] = URL::to('').'/products/';
        $data['serviceImageUrl'] = URL::to('').'/service_categories/';
        $data['attributes'] = [];
        $data['sliders'] = Slider::where('type' , 1)->orderby('order_number' , 'ASC')->get();
        $data['treanding_categories'] = Category::where('status' , 0)->orderby('updated_at' , 'DESC')->limit(4)->get();
        $data['latest_services'] = ServiceCategory::where('status' , 0)->orderby('updated_at' , 'DESC')->limit(4)->get();
        //$data['reviews'] = Review::join('users' , 'users.user_id' ,'=', 'reviews.user_id')->select('reviews.*','users.first_name','users.last_name','users.user_image','users.social_image')->orderby('created_at' , 'DESC')->offset(0)->limit(10)->get();
        $data['new_arivals'] = DB::table('products')->select('products.*', 'categories.title as categories_title')->join('categories' , 'products.cat_id','=','categories.id')->where('products.status',1)->where('categories.status' , 0)->offset(0)->limit(10)->get();
        return view('front/home/index' , $data);
    }
    
    public function firebase($device_token,$message) {
	//echo '<pre>';print_r($message);exit;
        // Message should contain key and value. It should be an array like =====  message=>'Hi test'
        $url = 'https://fcm.googleapis.com/fcm/send';
		
        $fields = array(
            'to' => $device_token,
            'content_available' => true,
	    'mutable_content' => true,
            'data' => $message,
	    'notification' =>  $message
        );
		//echo json_encode($fields);exit;
        // Authentication..... Identification for project on firebase

        $header = array(
            'Authorization:key =AAAAasYy5JQ:APA91bFfw0DZHXZIhb5or73hsMokgehBkyMJRx_NKo59DVwQiPerNERyiYQHyJXL8Vv39E4W5UHm3OOu0JUZ9vvya5BOOv_IWL0kQFYpjPDaF6isKqvu8x83TtYlgwVchuzEdNLw6WPH',
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
	    //echo '<pre>'; print_r($result);exit;
        if ($result === false) {
            die('Curl Failed: ' . curl_error($ch));
        }
        
        curl_close($ch);
        return $result;
    }
    
}
