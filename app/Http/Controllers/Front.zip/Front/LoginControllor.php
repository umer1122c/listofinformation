<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Admin;
use Session;
use Validator;
use App\Models\User;
use App\Models\Newsletter;
use App\Models\UserLoginData;
use App\Models\UserInsurance;
use App\Models\Testimonial;
use App\Models\Partner;
use App\Models\PartnerPlan;
use App\Models\CartItem;
use App\Models\Setting;
use App\Models\Former;
use App\Classes\CommonLibrary;
use commonHelper;
use Illuminate\Support\Facades\Hash;
use URL;
use DB;
use Mail;


class LoginControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    public function LoginForm(Request $request) { 
        $data['title'] = 'Login';
        $data['description'] = 'Login';
        $data['class'] = 'login';
        $request->redirect_url;
        if($request->redirect_url == ''){
            $data['redirect_url'] = url('/');
        }else{
            $data['redirect_url'] = $request->redirect_url;
        }
        return $data['redirect_url'];
        return view('front/auth/login' , $data);
    }
    
    public function signinForm(Request $request) { 
        $data['title'] = 'Sign up';
        $data['description'] = 'Sign up';
        $data['class'] = 'Sign Up';
        if($request->redirect_url == ''){
            $data['redirect_url'] = url('/');
        }else{
            $data['redirect_url'] = $request->redirect_url;
        }
        $data['login_type'] = 0;
        $data['login_id'] = 0;
        $data['referral_code'] = '';
        if($request->referral_code){
            $data['referral_code'] = $request->referral_code; 
        }
        return view('front/auth/signup' , $data);
    }
	
    public function showLoginForm(Request $request) { 
        $data['title'] = 'Login';
        $data['description'] = 'Login';
        $data['class'] = 'login';
        //return $request->redirect_url;
        if($request->redirect_url == ''){
            $data['redirect_url'] = url('/');
        }else{
            $data['redirect_url'] = $request->redirect_url;
        }
        if ($request->isMethod('get')) {
            $data['login_type'] = 0;
            $data['login_id'] = 0;
            $data['slug'] = 0;
            return view('front/auth/login' , $data);
        }else{
            if(isset($request->login_type) && $request->login_type > 0){
                $data['login_type'] = $request->login_type;
                if($request->login_id == ''){
                    $data['login_id'] = 0;
                    $data['slug'] = '';
                }else{
                    $data['login_id'] = $request->login_id;
                    if(isset($request->slug)){
                        $data['slug'] = $request->slug;
                    }else{
                        $data['slug'] = '';
                    }
                }
                
                return view('front/auth/login' , $data);
            }
            $login_type_value = $request->login_type_value;
            $email = $request->email;
            $password = $request->password;
            $validator = Validator::make($request->all(), [
                            'email' => 'required',
                            'password' => 'required',
                        ]);
            if ($validator->fails()) {
                return redirect('login')
                            ->withInput()
                            ->withErrors($validator);
            }else{
                $user = User::where('email', $email)->first();
                if($user){
                    $user_password = $user->password;
                    if(Hash::check($request->password, $user_password)){
                        if($user->user_image == ''){
                            if($user->social_image != ''){
                                $user_image = $user->social_image;
                            }else{
                                $user_image = url('/front/dummy_round.png');
                            }
                        }else{
                            $user_image = url('/') . '/users/'.$user->user_image;
                        }
                        Session::put('user_id', $user->user_id);
                        Session::put('first_name', $user->first_name);
                        Session::put('email', $user->email);
                        Session::put('last_name', $user->last_name);
                        Session::put('user_image', $user_image);
                        Session::put('user', '1');
                        Session::flash('error_msg', 'You are logined in successfully!'); 
                        return response()->json(['status'=>"success",'login_type' => $login_type_value],200);
                    }else{
                        Session::flash('error_msg', 'Email or password is invalid!'); 
                        return response()->json(['status'=>"failed"],200);
                    }
                }else{
                    Session::flash('error_msg', 'Email or password is invalid!'); 
                    return response()->json(['status'=>"failed"],200);   
                }
            }
        }
    }
    
    public function checkEmail(Request $request){
        try{
            $user = User::where('email', $request->email)->first();
            if($user){
                return response()->json(['status'=>"failed" , "message" => 'This email already exist in our database.'],200);
            }else{
                if($request->referral_code != ''){
                    $referral_code_exists = User::where('referral_code',$request->referral_code)->first();
                    if($referral_code_exists == null){
                        return ['status'=>"failed","message"=>'User enterd wrong referral code',"user_access" => 0];
                    }
                }
                $first_name = $request->first_name;
                $ref_code = substr(str_shuffle('123456789123456789123456789321654987'),0,4);
                $referral_code = strtolower(substr($first_name, 0, 4)).$ref_code;
                $user_id = time();
                $users = new User();
                $users->user_id = $user_id;
                $users->first_name = $request->first_name;
                $users->last_name = $request->last_name;
                $users->email = $request->email;
                $users->phone = $request->phone;
                $users->referral_code = $referral_code;
                $users->password = Hash::make($request->password);
                $users->save();
                if($request->referral_code != ''){
                    $ref_user_id = $referral_code_exists->user_id;
                    $amount = Setting::first()->referral_amount; 
                    DB::table('transactions')->insert(['from_user_id' => $ref_user_id ,'to_user_id' => $user_id , 'amount'=> $amount,'cash_flow_type'=> 1,'trans_type'=> 0,'status'=> 1,  'created_at' => date('Y-m-d h:i:s'), 'updated_at' => date('Y-m-d h:i:s')]);
                    DB::table('transactions')->insert(['from_user_id' => $user_id ,'to_user_id' => $ref_user_id ,'amount'=> $amount,'cash_flow_type'=> 0,'trans_type'=> 0,'status'=> 0,  'created_at' => date('Y-m-d h:i:s'), 'updated_at' => date('Y-m-d h:i:s')]);

                    $wallets1 = DB::table('wallets')->where('user_id' , $user_id)->first();
                    if($wallets1){
                        $total_amount = $wallets1->total_amount + $amount;
                        DB::table('wallets')->where('user_id', $user_id)->update(['total_amount' => $total_amount]);
                        //$this->send_wallet_email($jsonrequest['userFullname'],$jsonrequest['userEmail'],$amount);
                    }else{
                        DB::table('wallets')->insert(['user_id' => $user_id , 'total_amount' => $amount]);
                        //$this->send_wallet_email($jsonrequest['userFullname'],$jsonrequest['userEmail'],$amount);
                    }

                    $wallets2 = DB::table('wallets')->where('user_id' , $ref_user_id)->first();
                    if($wallets2){
                        $total_amount = $wallets2->total_amount + $amount;
                        DB::table('wallets')->where('user_id', $ref_user_id)->update(['total_amount' => $total_amount]);
                        //$this->send_wallet_email($ref_userFullname,$ref_userEmail,$amount);
                    }else{
                        DB::table('wallets')->insert(['user_id' => $ref_user_id , 'total_amount' => $amount]);
                        //$this->send_wallet_email($ref_userFullname,$ref_userEmail,$amount);
                    }
                    
                    //Send Notification
                    $this->sendNotificationToUser( $user_id , $ref_user_id,$amount);
                    //End Notification
                }
                $user = User::where('user_id',$user_id)->first();
                $link = '';
                $email_subject = 'Registration email';
                $user_name = $request->first_name;
                $email_from = 'hello@hushdng.com';
                //$this->send_email($request->email, $user_name, $email_subject, $email_from, $link, 'register_email');
                if($user->user_image == ''){
                    if($user->social_image != ''){
                        $user_image = $user->social_image;
                    }else{
                        $user_image = url('/front/dummy_round.png');
                    }
                }else{
                    $user_image = url('/') . '/users/'.$user->user_image;
                }
                Session::put('user_id', $user_id);
                Session::put('first_name', $request->first_name);
                Session::put('last_name', $request->last_name);
                Session::put('user_image', $user_image);
                return response()->json(['status'=>"success" , "message" => 'New account created successfully!'],200);  
            }
        } catch (Exception $ex) {
            return response()->json(['status'=>"failed" , "message" => 'Oops! went something wrong.'],200); 
        }
                
    }
    
    public function newsletter(Request $request){
        try{
            $user = Newsletter::where('email', $request->email)->first();
            if($user){
                return "allready_exist";
            }else{
                $users = new Newsletter();
                $users->email = $request->email;
                $users->created_at = time();
                $users->updated_at = time();
                $users->save();
                $link = '';
                $email_subject = 'Newsletter Email';
                $user_name = $request->email;
                $email_from = 'info@hushdng.com';
                $this->send_email($request->email, $user_name, $email_subject, $email_from, $link, 'newslatter_email');
                return "success";
            }
        } catch (Exception $ex) {
            return "failed";
        }
                
    }
	
    public function logout(Request $request) {
        $user_id = Session::get('user_id');
        $cartItem = CartItem::where('user_id' , $user_id)->delete();
        $request->session()->flush();
        Session::flash('logout_msg', 'Logged out successfully'); 
        return redirect('/');
    }
    
    public function forgetPassword(Request $request){
        if ($request->isMethod('get')) {
            return view('front/auth/forgot');
        }else{
            $email = $request->email;
            $users = User::where('email', $email)->first();
            if ($users) {
                $pin = base64_encode($email);
                $link = URL::to('/') . '/user/reset_password/' . $pin;
                $email_subject = 'Forgotten password';
                $user_name = $users->first_name;
                $email_from = 'info@hushdng.com';
                $this->send_email($email, $user_name, $email_subject, $email_from, $link, 'forget_email');
                Session::flash('success_msg', 'Please check email to reset password.'); 
                return response()->json(['status'=>"success"],200);
            }else{
                return response()->json(['status'=>"notexist"],200); 
            }
        }
    }
	
    public function send_email($email, $user_name, $email_subject, $email_from, $link,$view_name) {
        $res['userName'] = $user_name;
        $res['activationLink'] = $link;
        $res['url'] = url('/');
        //return view('email/'.$view_name , $res);
        Mail::send('email/'.$view_name , $res, function ($message) use ($email_from, $email, $user_name, $email_subject) {
            $message->from($email_from, $name = 'Hushdng');
            $message->to($email, $user_name)->subject($email_subject);
            $message->to('rizwan@decodershub.com', $user_name)->subject($email_subject);
        });
    }
	
    public function resetPassword(Request $request , $email = '') {
        if ($request->isMethod('get')) {
            $data['email'] = $email;
            return view('admin/login/reset_password', $data);
        }else{
            $validator = Validator::make($request->all(), [
                'new_password' => 'required|same:confirm_password',
                'confirm_password' => 'required',
            ]);
            if ($validator->fails()) {
                return redirect('user/reset_password/'.$email)
                        ->withInput()
                        ->withErrors($validator);

            }else{
                $user_email = base64_decode($email);
                $password = $request->input("new_password");

                User::where('email', $user_email)
                ->update(['password' => Hash::make($password)]);

                Session::flash('change_success_msg', 'your password has been reset successfully'); 
                return redirect('user/reset_password/'.$email);
            }
        }
    }
    
    public function sendNotificationToUser($ref_user_id , $user_id , $amount){
        $refusername = User::where('user_id' , $user_id)->first()->first_name;
        $othusername = User::where('user_id' , $ref_user_id)->first()->first_name;
        $users = UserLoginData::select('deviceToken','userId')->where('userId' , $user_id)->where('tokenStatus',0)->get();
        if(count($users) > 0){
            $deviceToken = [];
            foreach($users as $key => $val ){
                $deviceToken[] = $val->deviceToken;
                //$deviceToken[] = 'ep4JTpZFT-KsB8ejoM4NoI:APA91bHduV1A7Q3TtGI6PgX0GNEaZ-wPvEOQmctFxCqpf615h1v1JRLfx9lqinxF1n8_wYU0T9koz1g5k2H3Be6DAjwX-8o8qNg094O7tJ4WtW3aj9_jQSyhq7w3IAxa1-z89-d_kWXn';
            }
            $title = 'Referral code redeemed';
            $body = 'Hey '.$refusername.' your referral code has been redeemed by '.$othusername.' successfully.You will get ₦'.$amount.' once '.$othusername.' makes the first order.';
            $type = 'Referral';
            $message =  array(
                            'type' => 'notification',
                            'title' => $title,
                            'body' => $body,
                            'username' => $refusername,
                            'user_id' => $user_id,
                            'type1' => 'referral',
                            'sound'=> 'default',
                            'content-available'=> true,
                            'icon' => 'chat1'
                        );
            commonHelper::firebase($deviceToken,$message);
            commonHelper::saveNotification($ref_user_id,$user_id,$othusername,$title,$body,$type,0);
        }
    }
}