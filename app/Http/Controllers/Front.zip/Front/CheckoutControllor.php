<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\UserAddress;
use App\Models\Setting;
use App\Models\UserLoginData;
use App\Models\CartItem;
use App\Models\User;
use App\Models\Area;
use App\Models\BankInfo;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
use Illuminate\Support\Facades\Log;
use App\Classes\CommonLibrary;
use commonHelper;

class CheckoutControllor extends Controller
{
	
    public function __construct() {
        /** Paystack api context **/
        $settings = Setting::where('settings_id' , 1)->first();
        //dd($account);
        if($settings){
            if($settings->payment_mod == 1){
                config(['paystack.publicKey' => $settings->PAYSTACK_PUBLIC_KEY_LIVE]);
                config(['paystack.secretKey' => $settings->PAYSTACK_SECRET_KEY_LIVE]);
            }else{
                config(['paystack.publicKey' => $settings->PAYSTACK_PUBLIC_KEY_LOCAL]);
                config(['paystack.secretKey' => $settings->PAYSTACK_SECRET_KEY_LOCAL]);
            }
        }
    }
    
    
    public function index(Request $request){
        $data['title'] = 'Cart Checkout';
        $data['class'] = 'checkout';
        $data['table'] = 'Product Table';
        $user_id = session('user_id');
        $data['prodImageUrl'] = URL::to('').'/products/';
        $data['areas'] = Area::where('status' , 1)->orderby('name' , 'ASC')->get(); 
        $items = CartItem::Join('products', 'products.product_id', '=', 'cart_items.type_id')
                    ->select('cart_items.*' , 'products.product_title','products.product_images')
                    ->where('cart_items.user_id' , session('user_id'))
                    ->get();
        $subTotal = 0;
        $total = 0;
        if(count($items) > 0){
            foreach($items as $row){
                $price = $row->qty * ($row->price + $row->attributeCost);
                $subTotal = $subTotal + $price;
            }
        }
        $data['subTotal'] =  number_format($subTotal , 2);
        $data['totalAmount'] =  $subTotal;
        $data['min_shipping_cost'] = Setting::first()->min_shipping_cost;
        $data['max_shipping_v1'] = Setting::first()->max_shipping_v1;
        $data['max_shipping_v2'] = Setting::first()->max_shipping_v2;
        $data['max_shipping_v3'] = Setting::first()->max_shipping_v3;
        $address = UserAddress::Join('areas', 'user_address.area_id', '=', 'areas.id')->where('user_id' , session('user_id'))->get();  
        $data['address'] = $address;
        if(count($address) > 0){
            $value1 = $address[0]->value1 / 100;
            $value2 = $address[0]->value2 / 100;
            $value3 = $address[0]->value3 / 100;
            $shipping_cost = commonHelper::GetShippingCost($subTotal , $value1 , $value2 , $value3,$data['min_shipping_cost'],$data['max_shipping_v1'],$data['max_shipping_v2'],$data['max_shipping_v3']);
            $data['address_id'] =  $address[0]->address_id;
        }else{
            $shipping_cost = 0;
            $data['address_id'] = 0;
        }
        $total = $subTotal + $shipping_cost;
        $data['shipping_cost'] =  $shipping_cost;
        $data['total'] = $total;
        $available_balance = DB::table('transactions')->where('to_user_id' , $user_id)->whereIn('trans_type' , array(0,2))->where('status' , 1)->sum('amount');
        $withdrawal_balance = DB::table('transactions')->where('to_user_id' , $user_id)->where('trans_type' , 1)->sum('amount');
        $available_wallet_amount = $available_balance - $withdrawal_balance;
        if($available_wallet_amount > $subTotal){
            $data['available_wallet_amount'] = $subTotal;
        }else{
            $data['available_wallet_amount'] = number_format($available_balance - $withdrawal_balance, 2, '.', '');
        }
        $data['BankInfo'] = BankInfo::first();
        return view('front/checkout/index' , $data);
    }
}
