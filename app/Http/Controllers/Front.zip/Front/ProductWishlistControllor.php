<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Bookmark;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
use Illuminate\Support\Facades\Log;

class ProductWishlistControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    
    public function index(Request $request){
        
        $data['prodImageUrl'] = URL::to('').'/products/';
        $data['title'] = 'My Favorites';
        $data['class'] = 'favorites';
        $user_id = Session::get('user_id');
        $data['favorites'] = DB::table('bookmarks')->select('products.*','categories.title as categories_title')
                                ->join('products', 'products.product_id', '=', 'bookmarks.product_id')
                                ->join('categories', 'products.cat_id', '=', 'categories.id')
                                ->where('bookmarks.user_id' , $user_id)
                                ->paginate(12);
        //dd($data['favorites']);
        if ($request->ajax()) {
            return view('front/wishlist/productLoad',$data)->render();
        }
        return view('front/wishlist/index' , $data);
    }
    
    public function productFaviorty($status = '' , $product_id = ''){
        $user_id = Session::get('user_id');
        if($status == 1){
            Bookmark::insert(['user_id' => $user_id , 'product_id' => $product_id]);
            return response()->json(['status'=>"added","message"=>'Product has been added to favourites list.'],200);
        }else{
            Bookmark::where('user_id' , $user_id)->where('product_id' , $product_id)->delete();
            return response()->json(['status'=>"remove","message"=>'Product removed from your favourites list.'],200);
        }
    }
}
