<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Testimonial;
use App\Models\User;
use App\Models\Order;
use App\Models\Product;
use App\Models\Copoun;
use App\Models\CouponUser;
use App\Models\OrderDetail;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use Image;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
class OrderControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    public function index(Request $request)
    {
        $data['title'] = 'My Orders';
        $data['class'] = 'orders';
        $data['prodImageUrl'] = URL::to('').'/products/';
        $user_id = Session::get('user_id');
        $data['orders'] = DB::table('orders')->select('orders.order_id','orders.order_total','orders.discount_amount','orders.shipping_cost','orders.created_at','orders.dilivery_date','orders.status as order_status')
                            ->where('orders.user_id' , $user_id)
                            //->where('orders.status' , '!=' , 'Pending')
                            ->orderby('orders.created_at' , 'desc')
                            ->paginate(10);
        if ($request->ajax()) {
            return view('front/dashboard/ordersLoad',$data)->render(); 
        }
        return view('front/dashboard/orders',$data);
    }
    
    public function orderDetail($order_id = '')
    {
        $data['title'] = 'Order Detail';
        $data['class'] = 'orders';
        $prodImageUrl = URL::to('').'/products/';
//        $orders = Order::select('order_id','order_total','discount_amount','coupon_code','shipping_cost','address','status','wallet_amount','created_at as order_date','dilivery_date')->where('order_id' , $order_id)->first();
//        //dd($products);
//        $orderArray = [];
//        if($orders){
//            //return $orders->address;
//            $address = DB::table('user_address')
//                            ->select('user_address.*','areas.*')
//                            ->join('areas', 'areas.id', '=', 'user_address.area_id' , 'left')
//                            ->where('user_address.address_id' , $orders->address)
//                            ->first();
//            //dd($address);
//            if($address){
//                $orders->delivery_address = $address->house_name.' '.$address->street.' '.$address->town.' '.$address->name;
//                $orders->phone_number = $address->phone_number;
//            }
//            $orders->order_date = date('M d Y h:i A' , strtotime($orders->order_date));
//            $order_details = DB::table('order_details')->select('product_id','prod_title' , 'quantity' , 'price','pally_id','type','delivery_status')->where('order_id' , $orders->order_id)->get();
//            //$orders->order_details = $order_details;
//            foreach($order_details as $row){
//                
//                $products = Product::select('product_images')->where('product_id' , $row->product_id)->first();
//                if($products){
//                    $product_images = json_decode($products->product_images);
//                    if(count($product_images) > 0){
//                        $row->product_image = $prodImageUrl.$product_images[0]->imagePath;
//                    }else{
//                        $row->product_image = asset('front/placeholder.png');
//                    }
//                }else{
//                    $row->product_images = asset('front/placeholder.png');
//                }
//
//                if($row->pally_id == null){
//                    $row->pally_id = '';
//                }
//
//                $orderArray[] = $row;
//            }
//            $orders->order_details = $orderArray;
//            $data['order_detail'] = $orders;
//            //dd($data['order_detail']);
//            $data['item_array'] = $orderArray;
            return view('front/dashboard/orderDetail' , $data);
        //}else{
            //return redirect('my/orders');;
        //}
    }
    
    public function palliedFriends($pally_id , $order_id = '')
    {
        $data['title'] = 'Pallied Friends';
        $data['class'] = 'orders';
        $data['pally_id'] = $pally_id;
        $pally = DB::table('open_pallys')->select('pally_id','product_id','pally_type','number_of_person as pally_size')->where('pally_id' , $pally_id)->first();
        $usersArray = [];
        if($pally){
            $product = Product::where('product_id' , $pally->product_id)->first();
            if($product){
                $data['product_id'] = $product->product_id;
                $data['slug'] = $product->slug;
            }else{
                $data['product_id'] = '';
                $data['slug'] = '';
            }
            if($pally->pally_type == 'Open'){
                $pally_users =DB::table('close_pally_users')
                        ->select('close_pally_users.user_id','close_pally_users.status','users.first_name','users.last_name','users.user_image','users.social_image')
                        ->join('users', 'users.user_id', '=', 'close_pally_users.user_id')
                        ->where('close_pally_users.pally_id' , $pally_id)
                        ->get();
                //dd($pally_users);
                if(count($pally_users) > 0){
                    foreach($pally_users as $ord){
                        if($ord->status == 1){
                            $ord->order_status = 'Paid';
                        }else{
                            $ord->order_status = 'UnPaid';
                        }
                        if($ord->last_name == null){
                            $ord->last_name =  '';
                        }

                        if($ord->user_image == ''){
                            if($ord->social_image != ''){
                                $ord->user_image = $ord->social_image;
                            }else{
                                $ord->user_image = URL::to('/') .'/front/dummy_round.png';
                            }
                        }else{
                            $ord->user_image = URL::to('/') . '/users/'.$ord->user_image;
                        }
                        $usersArray[] = $ord;
                    }
                }
                $pally->pallyusers = $usersArray;
            }else{
                $pally_users =DB::table('close_pally_users')
                        ->select('close_pally_users.user_id','close_pally_users.status','users.first_name','users.last_name','users.user_image','users.social_image')
                        ->join('users', 'users.user_id', '=', 'close_pally_users.user_id')
                        ->where('close_pally_users.pally_id' , $pally_id)
                        ->get();
                //dd($pally_users);
                if(count($pally_users) > 0){
                    foreach($pally_users as $ord){
                        if($ord->status == 1){
                            $ord->order_status = 'Paid';
                        }else{
                            $ord->order_status = 'UnPaid';
                        }
                        if($ord->last_name == null){
                            $ord->last_name =  '';
                        }

                        if($ord->user_image == ''){
                            if($ord->social_image != ''){
                                $ord->user_image = $ord->social_image;
                            }else{
                                $ord->user_image = URL::to('/') .'/front/dummy_round.png';
                            }
                        }else{
                            $ord->user_image = URL::to('/') . '/users/'.$ord->user_image;
                        }
                        $usersArray[] = $ord;
                    }
                }
                $pally->pallyusers = $usersArray;
            }
            $data['pally_friends'] = $pally->pallyusers;
            //dd($data['pally_friends']);
            return view('front/orders/pallied_friends' , $data);
        }else{
            return response()->json(['status'=>"success","message"=>'No data found.','data' => []],200);
        }
    }
    
    public function applyCouponCode($code= '',$amount = ''){
        $user_id = Session::get('user_id');
        $Coupon = Copoun::where('code',$code)->where('status',0)->first();
        if($Coupon){
            $userCount = CouponUser::where('user_id' , $user_id)->where('coupon_code',$code)->count();
            //return $Coupon->no_of_time;
            if($userCount < $Coupon->no_of_time){
                if($amount <= $Coupon->min_price){
                    return response()->json(['status'=>"failed","message"=>"Cart amount is not sufficent for this refrelcode. Minimum amount -".$Coupon->min_price],200);
                }
                $discount = $Coupon->discount;
                $totalDiscount = $amount * $discount /100; 
                if($totalDiscount >= $Coupon->max_price_applay){
                    $totalDiscount = $Coupon->max_price_applay;
                }
                return response()->json(['status'=>"success","message"=>"Coupon Applied successfully.",'discount' => round($totalDiscount,2)],200,[],JSON_NUMERIC_CHECK);
            }else{
                return response()->json(['status'=>"failed","message"=>"Coupon code hass been expaired for this user.","user_access" => 0],200);
            }
        }else{
            return response()->json(['status'=>"failed","message"=>"Coupon code is incorrect.","user_access" => 0],200);
        }  
    }
    
    public function importOrders(Request $request)
    {
        $orderArray = [];
        $orders = Order::select('reference')->where('reference' ,'!=', '')->groupby('reference')->get()->toArray();
        if(count($orders) > 0){
            foreach($orders as $row){
                $ordersReference = Order::select('order_id','reference',DB::raw("SUM(orders.order_total) as order_total"),'user_id',DB::raw("SUM(orders.shipping_cost) as shipping_cost"),'deviceType','coupon_code','discount_amount','paystck_responce','status','dilivery_date','created_at')->where('reference' , $row['reference'])->get()->toArray();
                $order['orderref'] = $ordersReference;
                $order_id = $ordersReference[0]['order_id'];
                $ordersRefDet = Order::select('order_id')->where('reference' , $row['reference'])->get()->toArray();
                $orderDetail = OrderDetail::select('order_id','product_id','prod_title','quantity','price','pally_id','type','delivery_status','attribute_id','attribute_cost','attribute_name')->whereIn('order_id' , $ordersRefDet)->get()->toArray();
                if(count($orderDetail) > 0){
                    $itemArray = [];
                    foreach($orderDetail as $ordDet){
                        $ordDet['order_id'] = $order_id;
                        $itemArray[] = $ordDet;
                    }
                }
                //dd($itemArray); 
                $order['orderItems'] = $itemArray;
                $orderArray[] = $order;
            }
            //dd($orderArray);
            
            //return count($orderArray);
            
            $orderItemArrayNew = [];
            if(count($orderArray) > 0){
                foreach($orderArray as $order){
                    $orderref = $order['orderref'][0];
                    DB::table('orders_new')->insert($orderref);
                    $orderItems = $order['orderItems'];
                    DB::table('order_details_new')->insert($orderItems);
                    //exit;
                }
            }
        }
    }
}
