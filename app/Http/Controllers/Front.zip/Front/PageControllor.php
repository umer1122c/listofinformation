<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Product;
use App\Models\Media;
use App\Models\Team;
use Session;
use DB;
use Maatwebsite\Excel\Facades\Excel;
use URL;
use Validator;
use Illuminate\Support\Facades\Mail;

class PageControllor extends Controller
{
	
	public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
	
	
    public function index(){
        $data['title'] = 'Home';
        $data['description'] = '';
        $data['class'] = 'home';
        $data['table'] = 'Home';
        return view('front/pages/index' , $data);
    }
    
    public function work(){
        $data['title'] = 'How It Works';
        $data['description'] = '';
        $data['class'] = 'work';
        $data['table'] = 'How It Works';
        return view('front/pages/work' , $data);
    }
    
    public function thanks(){
        $data['title'] = 'Thanks for registerning!';
        $data['description'] = '';
        $data['class'] = 'thanks';
        $data['table'] = 'Thanks for registerning!';
        return view('front/pages/thanks' , $data);
    }
    
    public function pricing(){
        $data['title'] = 'Pricing';
        $data['description'] = '';
        $data['class'] = 'pricing';
        $data['table'] = 'Pricing';
        return view('front/pages/pricing' , $data);
    }

    public function media(Request $request){
        $data['title'] = 'Media';
        $data['description'] = '';
        $data['class'] = 'media';
        $data['table'] = 'Media';
        $data['mediaImageUrl'] = URL::to('').'/medias/';
        $data['medias'] = Media::where('status' , 1)->orderby('updated_at' , 'DESC')->paginate(12);
        if ($request->ajax()) {
            return view('front/pages/mediaLoad',$data)->render();
        }
        return view('front/pages/media' , $data);
    }
    
    public function about(){
        $data['title'] = 'About';
        $data['description'] = 'about';
        $data['class'] = 'about';
        $data['table'] = 'About';
        $data['teams'] = Team::orderby('id' , 'DESC')->paginate(8);
        return view('front/pages/about' , $data);
    }
    
    public function terms(){
        $data['title'] = 'Terms And Conditions';
        $data['description'] = '';
        $data['class'] = 'terms';
        $data['table'] = 'Terms And Conditions';
        return view('front/pages/terms' , $data);
    }
    
    public function return_policy(){
        $data['title'] = 'Return Policy';
        $data['description'] = '';
        $data['class'] = 'terms';
        $data['table'] = 'Return Policy';
        return view('front/pages/policy' , $data);
    }
    
    public function privacy_policy(){
        $data['title'] = 'Privacy Policy';
        $data['description'] = '';
        $data['class'] = 'privacy';
        $data['table'] = 'Privacy Policy';
        return view('front/pages/privacy_policy' , $data);
    }
    
    public function covid_policy(){
        $data['title'] = 'COVID-19 Policy';
        $data['description'] = '';
        $data['class'] = 'covid';
        $data['table'] = 'COVID-19 Policy';
        return view('front/pages/covid_policy' , $data);
    }
    
    public function contactus(Request $request){
        $data['title'] = 'Contact the Best Nigerian Grocery Store near you - Pricepally';
        $data['description'] = 'Pricepally committed to give you a great shopping experience! We are always available on call or you can write us on mail info@pricepally.com';
        $data['class'] = 'contactus';
        $data['table'] = 'Contact Us';
        if ($request->isMethod('get')) {
            return view('front/pages/contactus' , $data);
        }else{

            $validator = Validator::make($request->all(), [
                                'email' => 'required',
                                'name' => 'required',
                                'message' => 'required',
                            ]);
            if ($validator->fails()) {
                return redirect('contactus')
                        ->withInput()
                        ->withErrors($validator);
            }else{
                $parameaters = $request->all();
                //dd($parameaters);
                $email_subject = 'Contact Us';
                $user_name = 'Admin';
                $email_from = 'hello@pricepally.com';
                $this->send_email($user_name, $email_subject, $email_from,$parameaters, 'contact_email');
                Session::flash('success_msg', 'Thank you for contacting us. We will get back to you very soon.'); 
                return redirect('contactus');
            }
        }
    }
    
    public function send_email($user_name, $email_subject, $email_from,$parameaters, $view_name) {
        $res['userName'] = $user_name;
        $res['parameaters'] = $parameaters;
        $res['url'] = url('/');
        Mail::send('email/'.$view_name , $res, function ($message) use ($email_from, $user_name, $email_subject) {
            $message->from($email_from, $name = 'Pricepally');
            $message->to($email_from, $name = 'Pricepally')->subject($email_subject);
            $message->to('rizwan@decodershub.com', $user_name)->subject($email_subject);
        });
    }   
}