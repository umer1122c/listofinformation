<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\CartServiceItem;
use App\Models\Service;
use App\Models\Product;
use App\Models\Copoun;
use App\Models\UsedCoupon;
use App\Models\Attribute;
use App\Models\OrderAddress;
use App\Classes\CommonLibrary;
use commonHelper;
use App\Models\User;
use Helper;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use URL;

class CartController extends Controller
{
    public function index(){
        $data['title'] = 'Cart';
        $data['class'] = 'cart';
        $data['prodImageUrl'] = URL::to('').'/products/';
        $data['serviceImageUrl'] = URL::to('').'/service_categories/';
        $user_id = session('user_id');
        $items = CartItem::Join('products', 'products.product_id', '=', 'cart_items.type_id','left')->Join('service_categories', 'service_categories.service_category_id', '=', 'cart_items.type_id','left')
                    ->select('cart_items.*' ,'products.product_title','products.product_images','service_categories.title','service_categories.image')
                    ->where('cart_items.user_id' , $user_id)
                    ->get();
        //dd($items);
        $data['items'] = $items;
        return view('front/cart/index',$data);
    }
    
    public function addToCart(Request $request) { 
        $user_id = Session::get('user_id');
        $pally_id = $request->pally_id;
        $cartItem = CartItem::where('user_id' , $user_id)->where('type_id' , $request->id)->where('type','Product')->first();
        if($cartItem){
            $qty = $cartItem->qty + $request->qty;
            CartItem::where('user_id' , $user_id)->where('type_id' , $request->id)->update(['qty'=>$qty]);
            $cartCount = CartItem::where('user_id',session('user_id'))->count();
            $cartTotal = commonHelper::getCartTotalAmount();
            return response()->json(['status'=>"success","message"=>'Item added into cart successfully.','cartCount' => $cartCount,'cartTotal' => $cartTotal],200);
        }else{
            if($request->type == 'Product'){
                //Add cart
                $this->addCart($request->id,$request->name,$request->qty,$request->price,$request->type);
                //END
                $cartCount = CartItem::where('user_id',session('user_id'))->count();
                $cartTotal = commonHelper::getCartTotalAmount();
                return response()->json(['status'=>"success","message"=>'Item added into cart successfully.','cartCount' => $cartCount,'cartTotal' => $cartTotal],200);
            }elseif($request->type == 'Service'){
                $serviceArrayNew = [];
                $cart_id = substr(str_shuffle('123456789123456789123456789321654987'),0,8);
                $price = 0;
                $serviceArray = explode(',' , $request->services);
                if(count($serviceArray) > 0){
                    foreach($serviceArray as $key=>$val){
                        $serviceRes = Service::where('id' , $val)->first();
                        $serviceArrayNew[] = [
                            "cart_id"  => $cart_id,
                            "service_id"  => $val,
                            "service_name"  => $serviceRes->service_name,
                            "price"  => $serviceRes->price
                        ];
                        $price = $price + $serviceRes->price;
                    }
                }
                $data = [
                    "type_id"  => $request->id,
                    "cart_id"  => $cart_id,
                    "user_id"  => session('user_id'),
                    "name"  => $request->name,
                    "price"  => $price,
                    "type"  => $request->type,
                    "qty"  => 1,
                    "created_at"  => date('Y-m-d h:i:s'),
                    "updated_at"  => date('Y-m-d h:i:s'),
                ];
                $cartItem = CartItem::where('user_id' , session('user_id'))->where('type_id' , $request->id)->where('type','Service')->first();
                if($cartItem){
                    $cartCount = CartItem::where('user_id',session('user_id'))->count();
                    $cartTotal = commonHelper::getCartTotalAmount();
                    return ["status" => true,"message"=>"You already add this service in cart.",'cartCount' => $cartCount,'cartTotal' => $cartTotal];
                }else{
                    CartItem::insert($data);
                    CartServiceItem::insert($serviceArrayNew);
                    $cartCount = CartItem::where('user_id',session('user_id'))->count();
                    $cartTotal = commonHelper::getCartTotalAmount();
                    return ["status" => true,"message"=>"Service added into cart successfully.",'cartCount' => $cartCount,'cartTotal' => $cartTotal];
                }
            } 
        }
        
    }
    
    public function addCart($id,$name,$qty,$price,$type){
        $user_id = Session::get('user_id');
        
        $cartItems = new CartItem();
        $cartItems->user_id = $user_id;
        $cartItems->cart_id = substr(str_shuffle('123456789123456789123456789321654987'),0,8);
        $cartItems->type_id = $id;
        $cartItems->name = $name;
        $cartItems->qty = $qty;
        $cartItems->price = $price;
        $cartItems->type = $type;
        $cartItems->save();
        return 'success';
    }
    
    public function updateItem($id = '' , $qty){
        $cart =  CartItem::where('cart_id', $id)->update(['qty' => $qty]);
        if($cart){
            $data = CartItem::select('price','qty')->where('user_id',session('user_id'))->get();
            $total = 0;
            foreach ($data as $key => $value) {
                $total += $value->price*$value->qty;
            }
            $cartCount = CartItem::where('user_id',session('user_id'))->count();
            return response()->json(['status'=>"success","message"=>'Item quantity updated in cart successfully.','cartCount' => $cartCount,'total'=> number_format($total,2)],200);
        }else{
            return response()->json(['status'=>"fail","message"=>'Error accer during cart item deleting.'],200);
        }
    }
    
    public function updateCartQty(Request $request){
        $cartItem = Cart::where('user_id',session('user_id'))->where('product_id',commonHelper::getProductId($request->slug))->first();
        if($cartItem){
            if ($request->qty =='plus') {
                $qty = $cartItem->product_quentity +$request->product_quentity;
                Cart::where('user_id' ,session('user_id'))->where('product_id' , commonHelper::getProductId($request->slug))->update(['product_quentity'=>$qty]);
                $data = Cart::where('user_id',session('user_id'))->count();
                if($data == null){
                        return 0;
                    }else{
                        return $data;
                    }
            }else{
                $qty = $cartItem->product_quentity - $request->product_quentity;
                if ($qty == 0) {
                    Cart::where('user_id' , session('user_id'))->where('product_id' , commonHelper::getProductId($request->slug))->delete();
                    $data = Cart::where('user_id',session('user_id'))->count();
                    if($data == null){
                        return 0;
                    }else{
                        return $data;
                    }
                }else{
                    Cart::where('user_id' , session('user_id'))->where('product_id' , commonHelper::getProductId($request->slug))->update(['product_quentity'=>$qty]);
                    $data = Cart::where('user_id',session('user_id'))->count();
                    if($data == null){
                        return 0;
                    }else{
                        return $data;
                    }
                }
            }

        }

    }
    
    public function deleteCartItem($id = ''){
        $cart =  CartItem::where('cart_id', $id)->delete();
        if($cart){
            $data = CartItem::select('price','qty')->where('user_id',session('user_id'))->get();
            $total = 0;
            foreach ($data as $key => $value) {
                $total += $value->price*$value->qty;
            }
            $cartCount = CartItem::where('user_id',session('user_id'))->count();
            return response()->json(['status'=>"success","message"=>'Item deleted form cart successfully.','cartCount' => $cartCount,'total'=> number_format($total,2)],200);
        }else{
            return response()->json(['status'=>"fail","message"=>'Error accer during cart item deleting.'],200);
        }
    }
        
    public function checkcoupencode(Request $request){
        $price = 0;
        $code = $request->code;
        $copoun = Copoun::where('code',$code)->first();
        $cartvalues = Cart::select('product_price','product_quentity')->where('user_id',session('user_id'))->get();
        $cartSum = 0;
        foreach ($cartvalues as $key => $value) {
           $cartSum += $value->product_price * $value->product_quentity;
        }
        if(count(UsedCoupon::where('copoun_code',$code)->where('user_id',session('user_id'))->get()) > 0 ) {
            return 'alreadyUsed';
        }
        if ($copoun) {
            if ($cartSum >= $copoun->cart_min_value){
                $discountAmount = ($copoun->discount_percentage / 100) * $cartSum;
                if ($discountAmount >= $copoun->max_coupon_amount) {
                    $rodPoints = User::where('user_id',session('user_id'))->pluck('rod_points');
                    $totalRodPoints = $rodPoints[0] + $copoun->max_coupon_amount;
                    return  $cashback = $copoun->max_coupon_amount;
                }else if ( $discountAmount < $copoun->max_coupon_amount) {
                    return  $cashback = $discountAmount;
                }
            }else{
                return 'cartValueLow';
            }
        }else{
            return 'notExist' ; 
        }
        /*if (count($copounPrice) > 0) {
           if (count(UsedCoupon::where('copoun_code',$code)->where('user_id',session('user_id'))->get()) > 0 ) {
            return 'alreadyUsed';
            }else{
                return $copounPrice[0];
            } 
        }else{
            return 'notExist' ;

        }*/
    }

    public function savediscount(Request $request){
        $code = $request->code;
        $cashback_points = $request->cashback_points;
        $UsedCoupon =  new UsedCoupon();
        $UsedCoupon->copoun_code = $code;
        $UsedCoupon->user_id = session('user_id');
        $UsedCoupon->price = $cashback_points;
        $UsedCoupon->save();
    }

    public function cartTotalForMobile(){
        try {
            $data = Cart::where('user_id',session('user_id'))->get();
            $totalPrice = 0;
            foreach ($data as $key => $value) {
                $totalPrice += $value->product_quentity*$value->product_price;
            }
        } catch(Exception $e) {
            echo "ERROR:" . $e;
        }finally{ 
            return $totalPrice;
        }    
    }

    public function count_cart_item(Request $request){
        $data = Cart::where('user_id',session('user_id'))->count();
        if ($data == null) {
            return 0;
            Session::forget('pincode');
        }else{
           return $data; 
        }
    }

    public function checkpincode(Request $request){
        $data = OrderAddress::where('zipcode',$request->search_pincode)->count('id');
        if ($data == 0) {
            return 'invalid';
        }else{
            return 'valid';
            Session::put('pincode' , $request->search_pincode);
        }
    }
}