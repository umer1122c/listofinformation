<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\Slider;
use App\Models\UserLoginData;
use App\Models\Pally;
use App\Models\Follower;
use App\Models\User;
use App\Models\Attribute;
use App\Models\Review;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
use Illuminate\Support\Facades\Log;

class PallyProductControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    
    public function index($type = '',Request $request)
    {
        if($type == 'Open'){
            $data['title'] = 'Join an Open Pally Deal and Share Food Stuff with your Friends';
            $data['description'] = 'Join an open pally deal today! Select the food items that you want for your home and share the pally with your friends. Grab limited offers available.';
            $data['class'] = 'open_pally';
            $data['sliders'] = Slider::where('type' , 2)->orderby('order_number' , 'ASC')->get();
        }else{
            $data['title'] = 'Join an Close Pally Deal and Share Food Stuff with your Friends';
            $data['description'] = 'Join an close pally deal today! Select the food items that you want for your home and share the pally with your friends. Grab limited offers available.';
            $data['class'] = 'close_pally';
            $data['sliders'] = Slider::where('type' , 3)->orderby('order_number' , 'ASC')->get();
        }
        $data['prodImageUrl'] = URL::to('').'/products/';
        $user_id = Session::get('user_id');
        if($type == 'Open'){
            $data['products'] = DB::table('products')
                                ->select('products.product_id','products.is_season','products.product_title','products.slug','products.product_price','products.bulk_price','products.product_unit','products.product_description','products.product_images','open_pallys.id','open_pallys.pally_type','open_pallys.number_of_person','open_pallys.pally_count','open_pallys.pally_id','open_pallys.created_at')
                                ->join('open_pallys', 'open_pallys.product_id', '=', 'products.product_id')
                                ->where('open_pallys.status' , 0)
                                ->where('open_pallys.pally_type' , 'Open')
                                ->orderby('open_pallys.created_at' , 'DESC')
                                ->paginate(12);
        }else{
            $data['products'] = DB::table('products')
                                    ->select('products.product_id','products.is_season','products.product_title','products.slug','products.product_price','products.bulk_price','products.product_unit','products.product_description','products.product_images','open_pallys.id','open_pallys.pally_type','open_pallys.number_of_person','open_pallys.pally_count','open_pallys.pally_id','open_pallys.created_at')
                                    ->join('open_pallys', 'open_pallys.product_id', '=', 'products.product_id')
                                    ->join('close_pally_users', 'open_pallys.pally_id', '=', 'close_pally_users.pally_id')
                                    ->where('open_pallys.status' , 0)
                                    ->where('open_pallys.pally_type' , 'Close')
                                    ->where('close_pally_users.user_id',$user_id)
                                    ->where('open_pallys.user_id', '!=' ,$user_id)
                                    ->where('close_pally_users.status' , 0)
                                    ->orderby('open_pallys.created_at' , 'DESC')
                                    ->paginate(12);
            
        }
                            
        //dd($data['products']);
        if ($request->ajax()) {
            return view('front/pallys/pallyProductLoad',$data)->render();
        }
        return view('front/pallys/index' , $data);
    }
    
    public function existingPally($product_id = '',Request $request)
    {
        
        $data['title'] = 'Join an Open Pally Deal and Share Food Stuff with your Friends';
        $data['description'] = 'Join an open pally deal today! Select the food items that you want for your home and share the pally with your friends. Grab limited offers available.';
        $data['class'] = 'open_pally';
        $data['prodImageUrl'] = URL::to('').'/products/';
        $user_id = Session::get('user_id');
        $data['sliders'] = Slider::where('type' , 2)->orderby('order_number' , 'ASC')->get();
        $data['products'] = DB::table('products')
                            ->select('products.product_id','products.is_season','products.product_title','products.slug','products.product_price','products.bulk_price','products.product_unit','products.product_description','products.product_images','open_pallys.id','open_pallys.pally_type','open_pallys.number_of_person','open_pallys.pally_count','open_pallys.pally_id','open_pallys.created_at')
                            ->join('open_pallys', 'open_pallys.product_id', '=', 'products.product_id')
                            ->where('open_pallys.status' , 0)
                            ->where('open_pallys.pally_type' , 'Open')
                            ->where('open_pallys.product_id' , $product_id)
                            ->orderby('open_pallys.created_at' , 'DESC')
                            ->get();
        return view('front/pallys/indexExisting' , $data);
    }
    
    public function getExpallys($product_id = '',Request $request)
    {
        $pallys = DB::table('products')->join('open_pallys', 'open_pallys.product_id', '=', 'products.product_id')
                            ->where('open_pallys.status' , 0)
                            ->where('open_pallys.pally_type' , 'Open')
                            ->where('open_pallys.product_id' , $product_id)
                            ->count();
        if($pallys == 0){
            return 0;
        }elseif($pallys == 1){
            return $pallys.' pally already exists for this product';
        }else{
            return $pallys.' pallies already exists for this product';
        }
    }
    
    public function checkFollowers($size = '')
    {
        $user_id = Session::get('user_id');
        $size = $size - 1;
        $fallowers = Follower::Join('users', 'users.user_id', '=', 'followers.from_user_id')->select('from_user_id as user_id','is_follow','users.*')->where('to_user_id' , $user_id)->where('is_follow' , 1)->count();
        if($fallowers >= $size){
            return 1;
        }else{
            return 0;
        }
    }
    
    public function selectFollowers(Request $request)
    { 
        $data['title'] = 'Select Followers';
        $data['class'] = 'followers';
        $user_id = Session::get('user_id');
        $data['size'] = $request->size - 1;
        $data['pally_id'] = $request->pally_id;
        $data['product_id'] = $request->product_id;
        $data['name'] = $request->name;
        $data['price'] = $request->price;
        $data['attribute_id'] = $request->attribute_id;
        if($request->isMethod('get')){
            $data['fallowers'] = Follower::Join('users', 'users.user_id', '=', 'followers.from_user_id')->select('from_user_id as user_id','is_follow','users.*')->where('to_user_id' , $user_id)->where('is_follow' , 1)->get();
            if ($request->ajax()) {
                return view('front/pallys/followersSelecttLoad',$data)->render(); 
            }
            //dd($data['fallowers']);
            return view('front/pallys/followersSelect' , $data);
        }else{
            $keyword = $request->keyword;
            if($keyword != ''){
                $data['fallowers'] = Follower::Join('users', 'users.user_id', '=', 'followers.from_user_id')->select('from_user_id as user_id','is_follow','users.*')->where('users.first_name', 'like', '%'.$keyword.'%')->where('to_user_id' , $user_id)->where('is_follow' , 1)->get();
            }else{
                $data['fallowers'] = Follower::Join('users', 'users.user_id', '=', 'followers.from_user_id')->select('from_user_id as user_id','is_follow','users.*')->where('to_user_id' , $user_id)->where('is_follow' , 1)->get();
            }
            //dd($data['fallowers']);
            return view('front/pallys/followersSelecttLoad',$data)->render(); 
        }
    }
    
    public function createPally(Request $request)
    {
        $user_id = Session::get('user_id');
        $pallyArray = [];
        $pallyArray['pally_id'] = $request->pally_id;
        $pallyArray['user_id'] = $user_id;
        $pallyArray['pally_type'] = $request->pally_type;
        $pallyArray['product_id'] = $request->id;
        $pallyArray['number_of_person'] = $request->number_of_person;
        $pallyArray['created_at'] = time();
        $pallyArray['updated_at'] = time();
        DB::table('open_pallys')->insert($pallyArray);
        $user_idsArray = explode(',',$request->users);
        if($request->pally_type == 'Close'){
            if(count($user_idsArray) > 0){
                foreach($user_idsArray as $key => $val){
                    $pallyArray = [];
                    $pallyArray['type'] = 'Close';
                    $pallyArray['pally_id'] = $request->pally_id;
                    $pallyArray['user_id'] = $val;
                    $pallyArray['created_at'] = time();
                    $pallyArray['updated_at'] = time();
                    DB::table('close_pally_users')->insert($pallyArray);
                }
                //Current User entry
                $pallyCurrentUserArray = [];
                $pallyCurrentUserArray['type'] = 'Close';
                $pallyCurrentUserArray['pally_id'] = $request->pally_id;
                $pallyCurrentUserArray['user_id'] = Session::get('user_id');
                $pallyCurrentUserArray['created_at'] = time();
                $pallyCurrentUserArray['updated_at'] = time();
                DB::table('close_pally_users')->insert($pallyCurrentUserArray);
            }
        }
        return response()->json(['status'=>"success","message"=>'Item added into cart successfully.'],200);
    }
    
    public function detail($slug= '',$pally_id = '')
    {
        $proSlug = Product::where('slug',$slug)->first();
        $data['title'] = $proSlug->mata_title;
        $data['description'] = $proSlug->mata_description;
        $data['class'] = 'pally';
        $data['pally_id'] = $pally_id;
        $data['prodImageUrl'] = URL::to('').'/products/';
        
        $pally = DB::table('open_pallys')->where('pally_id' , $pally_id)->where('status' , 0)->first();
        //dd($pally);
        if($pally == null){
            Session::flash('success_msg', 'This link has been expired.');
            return view('errors/600' , $data);
        }
        
        if($pally){
            $data['number_of_person'] = $pally->number_of_person;
            $data['pally_count'] = $pally->pally_count;
            $data['created_at'] = $pally->created_at;
        }
        $product = Product::where('slug' , $slug)->first();
        $data['product'] = $product;
        
        $category = Category::where('id' , $product->cat_id)->first();
        if($category){
            $data['category'] = $category->title;
        }else{
            $data['category'] = '';
        }
        $data['offset'] = 0;
        $data['limit'] = 2;
        $data['total_reviews'] = Review::where('product_id' , $product->product_id)->count();
        
        $store_rating = Review::where('product_id' , $product->product_id)->where('status' , 0)->avg('rating');
        if($store_rating == null){
            $data['overall_rating'] = 0.00;
        }else{
            $data['overall_rating'] = number_format($store_rating,2);
        }
        $data['rating_count1'] = Review::where('product_id' , $product->product_id)->where('rating' ,'>=', 1)->where('rating' ,'<', 2)->where('status' , 0)->count();
        $data['rating_count2'] = Review::where('product_id' , $product->product_id)->where('rating' ,'>=', 2)->where('rating' ,'<', 3)->where('status' , 0)->count();
        $data['rating_count3'] = Review::where('product_id' , $product->product_id)->where('rating' ,'>=', 3)->where('rating' ,'<', 4)->where('status' , 0)->count();
        $data['rating_count4'] = Review::where('product_id' , $product->product_id)->where('rating' ,'>=', 4)->where('rating' ,'<', 5)->where('status' , 0)->count();
        $data['rating_count5'] = Review::where('product_id' , $product->product_id)->where('status' , 0)->where('rating' ,'>=', 5)->count();
        
        if($data['rating_count1'] > 0){
            $data['avg_rating_count1'] = number_format($data['rating_count1'] / $data['total_reviews'] * 100 , 2);
        }else{
            $data['avg_rating_count1'] = 0;
        }
        
        if($data['rating_count2'] > 0){
            $data['avg_rating_count2'] = number_format($data['rating_count2'] / $data['total_reviews'] * 100, 2);
        }else{
            $data['avg_rating_count2'] = 0;
        }
        
        if($data['rating_count3'] > 0){
            $data['avg_rating_count3'] = number_format($data['rating_count3'] / $data['total_reviews'] * 100 , 2);
        }else{
            $data['avg_rating_count3'] = 0;
        }
        
        if($data['rating_count4'] > 0){
            $data['avg_rating_count4'] = number_format($data['rating_count4'] / $data['total_reviews'] * 100, 2);
        }else{
            $data['avg_rating_count4'] = 0;
        }
        
        if($data['rating_count5'] > 0){
            $data['avg_rating_count5'] = number_format($data['rating_count5'] / $data['total_reviews'] * 100, 2);
        }else{
            $data['avg_rating_count5'] = 0;
        }
        $data['product_images'] = json_decode($product->product_images);
        $data['attributes'] = Attribute::where('product_id',$product->product_id)->get();
        $data['related_products'] = DB::table('products')->select('products.*')->join('categories' , 'products.cat_id','=','categories.id')->where('categories.status' , 0)->where('products.status',1)->where('products.cat_id' , $product->cat_id)->offset(0)->limit(10)->get();
        $data['recentaly_products'] = DB::table('products')->select('products.*')->join('categories' , 'products.cat_id','=','categories.id')->where('categories.status' , 0)->where('products.status',1)->orderby('products.total_views' , 'DESC')->offset(0)->limit(10)->get();
        //dd($data['related_products']);
        return view('front/pallys/detail' , $data);
    }
}