<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Bookmark;
use App\Models\ServiceCategory;
use App\Models\Service;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
use Illuminate\Support\Facades\Log;

class ServiceControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    
    public function index(Request $request){
        
        $data['serviceImageUrl'] = URL::to('').'/service_categories/';
        $data['title'] = 'Services';
        $data['class'] = 'services';
        $user_id = Session::get('user_id');
        $data['services'] = ServiceCategory::where('status' , 0)->orderby('updated_at' , 'DESC')->paginate(12);
        //dd($data['favorites']);
        if ($request->ajax()) {
            return view('front/services/productLoad',$data)->render();
        }
        return view('front/services/index' , $data);
    }
    
    public function getServices(Request $request)
    {
        $data['prodImageUrl'] = URL::to('').'/products/';
        $data['services_cat'] = ServiceCategory::where('service_category_id',$request->service_id)->first();
        $data['services'] = Service::where('service_category_id',$request->service_id)->get();
        return view('front/services/ServicePopupLoad' , $data);
    }
}
