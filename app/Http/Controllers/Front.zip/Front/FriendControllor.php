<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Follower;
use App\Models\UserLoginData;
use App\Models\User;
use Session;
use Validator;
use Illuminate\Support\Facades\Hash;
use File;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Mail;
use URL;
use Illuminate\Support\Facades\Log;
use App\Classes\CommonLibrary;
use commonHelper;

class FriendControllor extends Controller
{
	
    public function __construct() {
        $this->middleware('guest', ['except' => 'logout']);
    }
    
    
    public function index(Request $request){
        $data['title'] = 'Find Friends';
        $data['class'] = 'friend';
        $data['table'] = 'Find Friends';
        $data['attributes'] = [];
        $user_id = session('user_id');
        if ($request->isMethod('get')) {
            $data['users'] = User::where('user_id' , '!=' , $user_id)->paginate(10);
            if ($request->ajax()) {
                $data['users'] = User::where('user_id' , '!=' , $user_id)->paginate(10);
                return view('front/friends/friendLoad',$data)->render();
            }
            return view('front/friends/index' , $data);
        }else{
            $keyword = $request->keyword;
            if($keyword != ''){
                $data['users'] = User::where('user_id' , '!=' , $user_id)->where('first_name', 'like', '%'.$keyword.'%')->paginate(10);
            }else{
                $data['users'] = User::where('user_id' , '!=' , $user_id)->paginate(10);
            }
            //dd($data['users']);
            return view('front/friends/friendLoad',$data)->render();
        }
    }
    
    public function userFallow($status = '' , $user_id = ''){
        $current_user_id = Session::get('user_id');
        $fallower = Follower::where('from_user_id' , $current_user_id)->where('to_user_id' , $user_id)->first();
        if($fallower){
            if($fallower->is_follow == 1){
                Follower::where('from_user_id' , $current_user_id)->where('to_user_id' , $user_id)->update(['is_follow' => $status]);
                //return $status;
                $fallower = Follower::where('to_user_id' , $user_id)->where('is_follow' , 1)->count();
                return response()->json(['status'=>$status,"message"=>'you unfollowed this user successfully!','follow_count' => $fallower],200);
            }else{
                Follower::where('from_user_id' , $current_user_id)->where('to_user_id' , $user_id)->update(['is_follow' => $status]);
                //Send Notification
                $this->sendNotificationToUser($current_user_id , $user_id);
                //End Notification
                $fallower = Follower::where('to_user_id' , $user_id)->where('is_follow' , 1)->count();
                return response()->json(['status'=>$status,"message"=>'you followed this user successfully!','follow_count' => $fallower],200);
            }
        }else{
            $userFollow = new Follower();
            $userFollow->from_user_id = $current_user_id;
            $userFollow->to_user_id = $user_id;
            $userFollow->created_at = date('Y-m-d H:i:s');
            $userFollow->updated_at = date('Y-m-d H:i:s');
            $userFollow->save();
            //Send Notification
            $this->sendNotificationToUser($current_user_id , $user_id);
            //End Notification
            $fallower = Follower::where('to_user_id' , $user_id)->where('is_follow' , 1)->count();
                return response()->json(['status'=>1,"message"=>'you followed this user successfully!','follow_count' => $fallower],200);
        }
    }
    
    public function sendNotificationToUser($user_id , $follower_id){
        
        $username = User::where('user_id' , $user_id)->first()->first_name;
        $users = UserLoginData::select('deviceToken','userId')->where('userId' , $follower_id)->where('tokenStatus',0)->get();
        if(count($users) > 0){
            $deviceToken = [];
            foreach($users as $key => $val ){
                $deviceToken[] = $val->deviceToken;
                //$deviceToken[] = 'ep4JTpZFT-KsB8ejoM4NoI:APA91bHduV1A7Q3TtGI6PgX0GNEaZ-wPvEOQmctFxCqpf615h1v1JRLfx9lqinxF1n8_wYU0T9koz1g5k2H3Be6DAjwX-8o8qNg094O7tJ4WtW3aj9_jQSyhq7w3IAxa1-z89-d_kWXn';
            }
            $title = 'Pally follow';
            $body = $username.' just followed you, you can follow back to be able to chat or do a close pally together';
            $type = 'follow';
            $message =  array(
                            'type' => 'notification',
                            'title' => $title,
                            'body' => $body,
                            'username' => $username,
                            'user_id' => $user_id,
                            'type1' => 'follow',
                            'sound'=> 'default',
                            'content-available'=> true,
                            'icon' => 'chat1'
                        );
            commonHelper::firebase($deviceToken,$message);
            commonHelper::saveNotification($user_id,$follower_id,$username,$title,$body,$type,0);
        }
    }
}
