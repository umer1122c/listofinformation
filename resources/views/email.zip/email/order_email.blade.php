<p>
    Hi <?php echo $userName; ?>,
</p>
<p>
    Your orders detail here.
</p>
<table class="table table-invoice" border="1" style="width: 100%;">
    <thead>
        <tr>
            <th></th>
            <th>Items</th>
            <th class="text-center">Quantity</th>
            <th class="text-center">Price</th>
            <th class="text-center">Total</th>
        </tr>
    </thead>
    <tbody>
    @if(count($orders) > 0)
        <?php 
            $count = 1;
            $grandTotal = 0;
        ?>
        @foreach($orders as $row)
            <tr>
                <td>{{$count}}</td>
                <td>{{$row['prod_title']}}</td>
                <td class="text-center">{{$row['quantity']}}</td>
                
                <td class="text-center">₦{{number_format($row['price'], 2)}}</td>
                <td class="text-center">₦{{number_format($row['price'] * $row['quantity'] , 2)}}</td>
            </tr>
                <?php 
                    $total = $grandTotal + $row['price'] * $row['quantity']; 
                    $grandTotal = $total;
                ?>
        @endforeach
    @endif
        <tr>
            <td></td>
            <td></td>
            <td class="text-center"></td>
            <td class="text-center">Shipping Cost:</td>
            <td class="text-center">₦{{$shipping_cost}}</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td class="text-center"></td>
            <td class="text-center">Total :</td>
            <td class="text-center">₦{{number_format($grandTotal + $shipping_cost, 2)}}</td>
        </tr>
   </tbody>
</table>

<p>
    Kind regards,
    <br/>
    The Pricepally Team.
</p>