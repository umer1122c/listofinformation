<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Password Reset Instructions </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
        <style>
            body {
                font-family: 'Roboto', sans-serif;
                background: #f1f1f1;
            }

            .text-center {
                text-align: center;
            }

            .email-img {
                width: 15%;
                margin: 22px 0 0 0;
            }

            .forgot-inner {
                background: #fbfbfb;
                width: 60%;
                margin: 40px auto;
                box-shadow: 0 2px 8px hsl(0 0% 0% / 16%);
                padding: 26px;
                height: 100%;
            }

            .sub-btn {
                background: #ffb101;
                border: none;
                font-size: 14px;
                padding: 12px 40px;
                font-weight: 700;
                border-radius: 6px;
            }

            .forgot-content h2 {
                font-weight: 700;
                font-size: 36px;
                margin-bottom: 0;
            }

            .forgot-content p {
                padding: 0 86px;
                line-height: 23px;
                font-size: 14px;
                color: #131313;
            }

            .footer-bg img {
                width: 40px;
            }

            .footer-bg address {
                font-weight: bold;
                font-style: normal;
                font-size: 14px;
                margin: 6px 0 0 0;
            }

            .footer-bg address span {
                font-weight: 500;
            }

            .footer-bg {
                padding: 50px 0;
            }

            @media (max-width: 767.98px) {
                .forgot-inner {
                    width: 100%;
                    height: 430px;
                }
            }
        </style>

    </head>
    <body>
        <main>
            <!----- PASSWORD-SECTOION-START ------>
            <section class="forgot-bg">
                <div class="container">
                    <div class="forgot-inner">
                        <div class="text-center">
                            <a href="javascript:void(0)"><img class="flogo" src="{{$url}}/front/assets/images/logo.png" alt="logo.png"></a>
                        </div>
                        <div class="text-center">
                            <img class="email-img" src="{{$url}}/front/assets/images/email.png" alt='email'>
                        </div>
                        <div class="forgot-content">
                            <h2 class="text-center">Password Reset Instructions</h2>

                            <p><strong>Hi <?php echo $userName; ?>, here's how to reset your Password</strong></p>
                            <p>We have received a request to have your password reset for <a href="#">pricepally.com</a>. If you did not make this request, please ignore this email.</p>
                            <p>To reset your password, Please visit this link <a href="<?php echo $activationLink; ?>"><?php echo $activationLink; ?></a></p>
                        </div>
                        <div class="footer-bg text-center">
                            <img src="{{$url}}/front/assets/images/flogo.png">
                            <address>229- Malvin Road</address>
                            <address>Contact us: <span>+2347045000137
                            </span></address>
                        </div>
                    </div>
                </div>
            </section>
            <!----- PASSWORD-SECTOION-END ------>

        </main>
    </body>
</html>




<!DOCTYPE html>
<html lang="en">
<head>
    <title>Password Reset Instructions </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f1f1f1;
        }
        
        .text-center {
            text-align: center;
        }
        
        .email-img {
            width: 15%;
            margin: 22px 0 0 0;
        }
        
        .forgot-inner {
            background: #fbfbfb;
            width: 60%;
            margin: 40px auto;
            box-shadow: 0 2px 8px hsl(0 0% 0% / 16%);
            padding: 26px;
            height: 100%;
        }
        
        .sub-btn {
            background: #ffb101;
            border: none;
            font-size: 14px;
            padding: 12px 40px;
            font-weight: 700;
            border-radius: 6px;
        }
        
        .forgot-content h2 {
            font-weight: 700;
            font-size: 36px;
            margin-bottom: 0;
        }
        
        .forgot-content p {
            padding: 0 86px;
            line-height: 23px;
            font-size: 14px;
            color: #131313;
        }
        
        @media (max-width: 767.98px) {
            .forgot-inner {
                width: 100%;
                height: 430px;
            }
        }
    </style>

</head>

<body>
    <main>
        <!----- PASSWORD-SECTOION-START ------>
        <section class="forgot-bg">
            <div class="container">
                <div class="forgot-inner">
                    <div class="text-center">
                        <a href="javascript:void(0)"><img class="flogo" src="assets/images/logo.png" alt="logo.png"></a>

                    </div>
                    <div class="text-center">
                        <img class="email-img" src="assets/images/email.png" alt='email'>
                    </div>
                    <div class="forgot-content">
                        <h2 class="text-center">Password Reset Instructions</h2>

                        <p><strong>Hi <?php echo $userName; ?>, here's how to reset your Password</strong></p>
                        <p>We have received a request to have your password reset for <a href="#">pricepally.com</a>. If you did not make this request, please ignore this email.</p>
                        <p>To reset your password, Please visit this link <a href="<?php echo $activationLink; ?>"><?php echo $activationLink; ?></a></p>
                    </div>
                </div>

            </div>
        </section>
        <!----- PASSWORD-SECTOION-END ------>

    </main>
</body>
</html>