<!DOCTYPE html>
<html lang="en">

<head>
    <title>Verify-Email</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f1f1f1;
        }
        
        .text-center {
            text-align: center;
        }
        
        .regi-img {
            width: 16%;
            margin: 20px 0 0 0;
        }
        
        .registraion-inner {
            background: #fbfbfb;
            width: 60%;
            margin: 40px auto;
            box-shadow: 0 2px 8px hsl(0 0% 0% / 16%);
            padding: 26px;
            height: 100%;
        }
        
        .sub-btn {
            background: #ffb101;
            border: none;
            font-size: 14px;
            padding: 12px 40px;
            font-weight: 700;
            border-radius: 6px;
        }
        
        .registraion-content h2 {
            font-weight: 700;
            font-size: 36px;
            margin-bottom: 12px;
        }
        
        .registraion-content p {
            padding: 0 86px;
            line-height: 23px;
            font-size: 14px;
            color: #131313;
        }
        
        .footer-bg img {
            width: 40px;
        }
        
        .footer-bg address {
            font-weight: bold;
            font-style: normal;
            font-size: 14px;
            margin: 6px 0 0 0;
        }
        
        .footer-bg address span {
            font-weight: 500;
        }
        
        .footer-bg {
            padding: 50px 0;
        }
        
        @media (max-width: 767.98px) {
            .registraion-inner {
                width: 100%;
                height: 100%;
            }
        }
    </style>

</head>

<body>
    <main>
        <!----- REGISTRATION-SECTOION-START ------>
        <section class="registration-bg">
            <div class="container">
                <div class="registraion-inner">
                    <div class="text-center">
                        <a href="javascript:void(0)"><img class="flogo" src="{{$url}}/front/assets/images/logo.png" alt="logo.png"></a>

                    </div>
                    <div class="text-center">
                        <img class="regi-img" src="{{$url}}/front/assets/images/registration.png" alt='email'>
                    </div>
                    <div class="registraion-content text-center">
                        <h2 class="text-center">Welcome</h2>
                        <img class="banner-img" src="{{$url}}/front/assets/images/banner.jpg">
                        <p>Thanks for joining Pricepally, we are all about enabling sharing. When we share we get more for less and sharing is caring. Its the new economy and it excites us to do this!</p>

                        <div class="footer-bg text-center">
                            <img src="{{$url}}/front/assets/images/flogo.png">
                            <address>229- Malvin Road</address>
                            <address>Contact us: <span>+2347045000137
                            </span></address>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!----- REGISTRATION-SECTOION-END ------>

    </main>
</body>
</html>