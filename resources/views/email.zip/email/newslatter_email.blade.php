<!DOCTYPE html>
    <head>
        <title>Our Newsletter</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
        <style>
            body {
                font-family: 'Roboto', sans-serif;
                background: #f1f1f1;
            }

            .text-center {
                text-align: center;
            }

            .email-img {
                width: 15%;
                margin: 22px 0 0 0;
            }

            .newsletter-inner {
                background: #fbfbfb;
                width: 60%;
                margin: 40px auto;
                box-shadow: 0 2px 8px hsl(0 0% 0% / 16%);
                padding: 26px;
                height: 100%;
            }

            .sub-btn {
                background: #ffb101;
                border: none;
                font-size: 14px;
                padding: 12px 40px;
                font-weight: 700;
                border-radius: 6px;
            }

            .newsletter-content h2 {
                font-weight: 700;
                font-size: 36px;
                margin-bottom: 0;
            }

            .newsletter-content p {
                padding: 0 86px;
                line-height: 23px;
                font-size: 14px;
                color: #131313;
            }

            .footer-bg img {
                width: 40px;
            }

            .footer-bg address {
                font-weight: bold;
                font-style: normal;
                font-size: 14px;
                margin: 6px 0 0 0;
            }

            .footer-bg address span {
                font-weight: 500;
            }

            .footer-bg {
                padding: 50px 0;
            }

            @media (max-width: 767.98px) {
                .newsletter-inner {
                    width: 100%;
                    height: 430px;
                }
            }
        </style>

    </head>
    <body>
        <main>
            <!----- NEWSLETTER-SECTOION-START ------>
            <section class="newsletter-bg">
                <div class="container">
                    <div class="newsletter-inner">
                        <div class="text-center">
                            <a href="javascript:void(0)"><img class="flogo" src="{{$url}}/front/assets/images/logo.png" alt="logo.png"></a>
                        </div>
                        <div class="text-center">
                            <img class="email-img" src="{{$url}}/front/assets/images/email.png" alt='email'>
                        </div>
                        <div class="newsletter-content text-center">
                            <h2>Subscribe To Our Newsletter </h2>
                            <p>Subscribe to our email newsletter today to recevie updates on the latest news, tutorials and special offers !</p>
                            <p>Thanks for signing up. You must confirm your email address before we can send you. Please check your email and follow the instructions.</p>
                            <button class="sub-btn">Subscribe Now</button>
                            <p><strong>We respect your privacy. Your information is safe and will never be shared.</strong></p>
                            <div class="footer-bg text-center">
                                <img src="{{$url}}/front/assets/images/flogo.png">
                                <address>229- Malvin Road</address>
                                <address>Contact us: <span>+2347045000137
                                </span></address>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!----- NEWSLETTER-SECTOION-END ------>
        </main>
    </body>
</html>