<p>
    Hi <?php echo $userName; ?>,
</p>
<p>
    {{$usermessage}}
</p>
<p>
    Kind regards,
    <br/>
    The Pricepally Team.
</p>