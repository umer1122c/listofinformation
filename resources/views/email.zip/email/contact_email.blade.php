<!DOCTYPE html>
<html lang="en">
<head>
    <title>Our Newsletter</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f1f1f1;
        }
        .text-center {
            text-align: center;
        }
        .email-img {
            width: 15%;
            margin: 22px 0 0 0;
        }
        .contact-inner {
            background: #fbfbfb;
            width: 60%;
            margin: 40px auto;
            box-shadow: 0 2px 8px hsl(0 0% 0% / 16%);
            padding: 26px;
            height: 100%;
        }
        .sub-btn {
            background: #ffb101;
            border: none;
            font-size: 14px;
            padding: 12px 40px;
            font-weight: 700;
            border-radius: 6px;
        }
        .contact-content h2 {
            font-weight: 700;
            font-size: 36px;
            margin-bottom: 0;
        }
        .contact-content p {
            padding: 0 78px;
            line-height: 23px;
            font-size: 14px;
            color: #131313;
        }
        .contact-content ul {
            list-style: none;
        }
        .contact-content ul li {
            display: inline-block;
        }
        .footer-bg img {
            width: 40px;
        }
        .footer-bg address {
            font-weight: bold;
            font-style: normal;
            font-size: 14px;
            margin: 6px 0 0 0;
        }
        
        .footer-bg address span {
            font-weight: 500;
        }
        
        .footer-bg {
            padding: 50px 0;
        }
        
        @media (max-width: 767.98px) {
            .contact-inner {
                width: 100%;
                height: 430px;
            }
        }
    </style>

</head>
<body>
    <main>
        <!----- CONTACT-SECTOION-START ------>
        <section class="contact-bg">
            <div class="container">
                <div class="contact-inner">
                    <div class="text-center">
                        <a href="javascript:void(0)"><img class="flogo" src="{{$url}}/front/assets/images/logo.png" alt="logo.png"></a>
                    </div>
                    <div class=" text-center">
                        <img class="email-img" src="{{$url}}/front/assets/images/answer.png" alt='email'>
                    </div>
                    <div class="contact-content">
                        <h2 class="text-center">Send us a Message </h2>
                        <ul>
                            <li>
                                <p>
                                    <Strong>Name</Strong>
                                </p>
                                <p>{{$parameaters['name']}}</p>
                                <p>
                            </li>
                            <li>
                                <p>
                                    <Strong>Email</Strong>
                                </p>
                                <p>{{$parameaters['email']}}</p>
                            </li>
                            <li>
                                <p>
                                    <Strong>Phone</Strong>
                                </p>
                                <p>{{$parameaters['phone']}}</p>
                            </li>
                            <li>
                                <p>
                                    <Strong>Message</Strong>
                                </p>
                                <p>{{$parameaters['message']}}</p>
                            </li>
                        </ul>
                        <div class="footer-bg text-center">
                            <img src="{{$url}}/front/assets/images/flogo.png">
                            <address>229- Malvin Road</address>
                            <address>Contact us: <span>+2347045000137
                            </span></address>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!----- CONTACT-SECTOION-END ------>
    </main>
</body>
</html>